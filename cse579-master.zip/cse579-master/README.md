# CSE579 Fall 2019 Final Project
James Smith, Pavan Kumar Kintali, Nilesh Mutyam, Praveen Muruganandam
## Automated Warehouse Scenario
### Instructions
To run the program, you just need the warehouse.lp file and the instance (inst#.asp) files in the same directory.
Make sure clingo is installed and set in your PATH setting.

#### Command line argument descriptions
(-t 4): This argument sets the number of threads to use. We set it to 4 to take advantage of the four cores available
to the system.

(-c t=13): This argument sets the maximum number of steps the solver will use to find a solution. Increasing this
value increases the execution time complexity. If the solver is taking too long to finish, try reducing this
value.

Run the following commands from the same directory as the .lp and .asp files:

#### Satisfiable Cases
```
clingo warehouse.lp inst1.asp -t 4 -c t=13
clingo warehouse.lp inst2.asp -t 4 -c t=13
clingo warehouse.lp inst3.asp -t 4 -c t=13
clingo warehouse.lp inst4.asp -t 4 -c t=11
clingo warehouse.lp inst5.asp -t 4 -c t=13
```

#### Unsatisfiable Case
```
clingo warehouse.lp inst1.asp -t 4 -c t=12
```

### Execution Results

#### clingo warehouse.lp inst1.asp -t 4 -c t=13
================================================================================
clingo version 5.4.0
Reading from warehouse.lp ...
Solving...
Progression : [1;inf]
Progression : [2;inf]
Answer: 1
occurs(object(robot,2),move(-1,0),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(0,1),3) occurs(object(robot,1),move(-1,0),3) occurs(object(robot,2),move(0,-1),5) occurs(object(robot,1),move(-1,0),5) occurs(object(robot,2),move(1,0),7) occurs(object(robot,1),move(1,0),7) occurs(object(robot,2),move(1,0),8) occurs(object(robot,1),move(0,-1),9) occurs(object(robot,2),move(0,-1),10) occurs(object(robot,1),move(1,0),11) occurs(object(robot,1),move(0,-1),12) occurs(object(robot,2),move(1,0),12) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,4) occurs(object(robot,2),putdown,6) occurs(object(robot,1),putdown,8) occurs(object(robot,2),pickup,9) occurs(object(robot,1),pickup,10) occurs(object(robot,2),deliver(1,3,4),4) occurs(object(robot,1),deliver(1,1,1),6) occurs(object(robot,2),deliver(3,4,1),11) occurs(object(robot,1),deliver(2,2,1),13)
Optimization: 13
Progression : [ 3;13] (Error: 3.33333)
Progression : [ 4;13] (Error: 2.25)
Progression : [ 5;13] (Error: 1.6)
Progression : [ 6;13] (Error: 1.16667)
Progression : [ 7;13] (Error: 0.857143)
Progression : [ 8;13] (Error: 0.625)
Progression : [ 9;13] (Error: 0.444444)
Progression : [10;13] (Error: 0.3)
Progression : [11;13] (Error: 0.181818)
Progression : [12;13] (Error: 0.0833333)
OPTIMUM FOUND

Models       : 1
  Optimum    : yes
Optimization : 13
Calls        : 1
Time         : 35.039s (Solving: 2.01s 1st Model: 1.49s Unsat: 0.52s)
CPU Time     : 40.144s
Threads      : 4        (Winner: 2)

================================================================================
#### clingo warehouse.lp inst2.asp -t 4 -c t=13
================================================================================

clingo version 5.4.0
Reading from warehouse.lp ...
Solving...
Progression : [1;inf]
Progression : [2;inf]
Answer: 1
occurs(object(robot,1),move(0,-1),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,1),move(1,0),4) occurs(object(robot,2),move(1,0),4) occurs(object(robot,2),move(0,-1),5) occurs(object(robot,1),move(-1,0),5) occurs(object(robot,1),move(0,1),7) occurs(object(robot,1),move(-1,0),8) occurs(object(robot,2),move(0,1),8) occurs(object(robot,1),move(-1,0),10) occurs(object(robot,2),move(-1,0),10) occurs(object(robot,2),move(-1,0),11) occurs(object(robot,1),move(1,0),12) occurs(object(robot,2),move(0,1),12) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,3) occurs(object(robot,1),putdown,6) occurs(object(robot,2),putdown,7) occurs(object(robot,2),pickup,9) occurs(object(robot,1),pickup,9) occurs(object(robot,2),deliver(2,2,1),6) occurs(object(robot,1),deliver(1,1,1),11) occurs(object(robot,2),deliver(1,3,2),13)
Optimization: 13
Progression : [ 3;13] (Error: 3.33333)
Progression : [ 4;13] (Error: 2.25)
Progression : [ 5;13] (Error: 1.6)
Progression : [ 6;13] (Error: 1.16667)
Answer: 2
occurs(object(robot,2),move(0,1),1) occurs(object(robot,1),move(0,-1),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(-1,0),3) occurs(object(robot,1),move(1,0),5) occurs(object(robot,1),move(0,1),6) occurs(object(robot,2),move(0,-1),7) occurs(object(robot,1),move(0,1),7) occurs(object(robot,1),move(-1,0),8) occurs(object(robot,2),move(1,0),9) occurs(object(robot,1),move(-1,0),9) occurs(object(robot,1),move(0,-1),10) occurs(object(robot,2),move(1,0),11) occurs(object(robot,1),move(-1,0),11) occurs(object(robot,2),move(0,-1),12) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,3) occurs(object(robot,2),putdown,8) occurs(object(robot,2),pickup,10) occurs(object(robot,2),deliver(1,1,1),6) occurs(object(robot,1),deliver(1,3,2),12) occurs(object(robot,2),deliver(2,2,1),13)
Optimization: 12
Progression : [ 7;12] (Error: 0.714286)
Answer: 3
occurs(object(robot,2),move(0,1),1) occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(0,-1),2) occurs(object(robot,2),move(-1,0),3) occurs(object(robot,1),move(1,0),6) occurs(object(robot,2),move(0,-1),7) occurs(object(robot,1),move(0,1),7) occurs(object(robot,1),move(0,1),8) occurs(object(robot,2),move(1,0),9) occurs(object(robot,1),move(-1,0),9) occurs(object(robot,1),move(-1,0),10) occurs(object(robot,2),move(1,0),11) occurs(object(robot,1),move(-1,0),11) occurs(object(robot,1),move(0,-1),12) occurs(object(robot,2),move(0,-1),12) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,3) occurs(object(robot,2),putdown,8) occurs(object(robot,2),pickup,10) occurs(object(robot,2),deliver(1,1,1),6) occurs(object(robot,2),deliver(2,2,1),13) occurs(object(robot,1),deliver(1,3,2),13)
Optimization: 11
Progression : [ 8;11] (Error: 0.375)
Progression : [ 9;11] (Error: 0.222222)
Progression : [10;11] (Error: 0.1)
OPTIMUM FOUND

Models       : 3
  Optimum    : yes
Optimization : 11
Calls        : 1
Time         : 90.057s (Solving: 2.17s 1st Model: 1.24s Unsat: 0.32s)
CPU Time     : 94.549s
Threads      : 4        (Winner: 1)

================================================================================
#### clingo warehouse.lp inst3.asp -t 4 -c t=13
================================================================================

clingo version 5.4.0
Reading from warehouse.lp ...
Solving...
Progression : [1;inf]
Answer: 1
occurs(object(robot,1),move(0,-1),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,1),move(0,-1),4) occurs(object(robot,2),move(1,0),4) occurs(object(robot,2),move(0,-1),5) occurs(object(robot,1),move(1,0),5) occurs(object(robot,1),move(0,1),6) occurs(object(robot,1),move(-1,0),7) occurs(object(robot,2),move(1,0),9) occurs(object(robot,1),move(0,-1),9) occurs(object(robot,2),move(0,1),10) occurs(object(robot,2),pickup,1) occurs(object(robot,1),pickup,3) occurs(object(robot,2),putdown,6) occurs(object(robot,2),pickup,7) occurs(object(robot,2),deliver(1,2,1),8) occurs(object(robot,1),deliver(2,4,1),10)
Optimization: 10
Progression : [ 2;10] (Error: 4)
Progression : [ 3;10] (Error: 2.33333)
Answer: 2
occurs(object(robot,2),move(1,0),1) occurs(object(robot,1),move(0,-1),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(-1,0),2) occurs(object(robot,1),move(0,-1),4) occurs(object(robot,2),move(1,0),4) occurs(object(robot,2),move(0,-1),7) occurs(object(robot,1),move(1,0),7) occurs(object(robot,2),move(0,1),11) occurs(object(robot,2),pickup,3) occurs(object(robot,1),pickup,3) occurs(object(robot,2),putdown,12) occurs(object(robot,1),deliver(2,4,1),5) occurs(object(robot,2),deliver(1,2,1),10)
Optimization: 9
Answer: 3
occurs(object(robot,2),move(1,0),1) occurs(object(robot,1),move(0,-1),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(-1,0),2) occurs(object(robot,1),move(0,-1),4) occurs(object(robot,2),move(1,0),4) occurs(object(robot,2),move(0,-1),7) occurs(object(robot,1),move(1,0),7) occurs(object(robot,2),move(0,1),11) occurs(object(robot,2),pickup,3) occurs(object(robot,1),pickup,3) occurs(object(robot,1),deliver(2,4,1),5) occurs(object(robot,2),deliver(1,2,1),10)
Optimization: 8
Answer: 4
occurs(object(robot,2),move(1,0),1) occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(0,-1),3) occurs(object(robot,1),move(0,-1),3) occurs(object(robot,2),move(1,0),5) occurs(object(robot,1),move(1,0),5) occurs(object(robot,2),move(0,1),7) occurs(object(robot,1),move(0,-1),7) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,4) occurs(object(robot,2),deliver(2,4,1),4) occurs(object(robot,1),deliver(1,2,1),11)
Optimization: 7
Progression : [4;7] (Error: 0.75)
Progression : [5;7] (Error: 0.4)
Progression : [6;7] (Error: 0.166667)
OPTIMUM FOUND

Models       : 4
  Optimum    : yes
Optimization : 7
Calls        : 1
Time         : 26.561s (Solving: 1.30s 1st Model: 0.05s Unsat: 1.00s)
CPU Time     : 29.509s
Threads      : 4        (Winner: 1)

================================================================================
#### clingo warehouse.lp inst4.asp -t 4 -c t=11
================================================================================

clingo version 5.4.0
Reading from warehouse.lp ...
Solving...
Progression : [1;inf]
Progression : [2;inf]
Answer: 1
occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(0,-1),2) occurs(object(robot,1),move(1,0),4) occurs(object(robot,2),move(1,0),4) occurs(object(robot,2),move(0,-1),5) occurs(object(robot,1),move(-1,0),5) occurs(object(robot,1),move(0,1),7) occurs(object(robot,1),move(-1,0),8) occurs(object(robot,1),move(-1,0),10) occurs(object(robot,2),pickup,1) occurs(object(robot,1),pickup,3) occurs(object(robot,1),putdown,6) occurs(object(robot,2),putdown,8) occurs(object(robot,1),pickup,9) occurs(object(robot,2),deliver(2,2,1),6) occurs(object(robot,2),deliver(3,2,2),7) occurs(object(robot,1),deliver(1,1,1),11)
Optimization: 11
Progression : [ 3;11] (Error: 2.66667)
Progression : [ 4;11] (Error: 1.75)
Progression : [ 5;11] (Error: 1.2)
Progression : [ 6;11] (Error: 0.833333)
Progression : [ 7;11] (Error: 0.571429)
Answer: 2
occurs(object(robot,2),move(0,-1),1) occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(0,-1),2) occurs(object(robot,2),move(-1,0),3) occurs(object(robot,1),move(-1,0),3) occurs(object(robot,2),move(0,1),5) occurs(object(robot,1),move(0,-1),5) occurs(object(robot,1),move(1,0),6) occurs(object(robot,2),move(0,1),6) occurs(object(robot,2),move(1,0),7) occurs(object(robot,2),move(-1,0),9) occurs(object(robot,2),pickup,2) occurs(object(robot,2),putdown,4) occurs(object(robot,1),pickup,4) occurs(object(robot,2),pickup,8) occurs(object(robot,1),deliver(3,2,2),7) occurs(object(robot,1),deliver(3,2,0),8) occurs(object(robot,1),deliver(2,2,1),9) occurs(object(robot,2),deliver(1,1,1),10) occurs(object(robot,1),deliver(2,2,0),10)
Optimization: 10
Progression : [ 8;10] (Error: 0.25)
Progression : [ 9;10] (Error: 0.111111)
OPTIMUM FOUND

Models       : 2
  Optimum    : yes
Optimization : 10
Calls        : 1
Time         : 61.640s (Solving: 0.74s 1st Model: 0.12s Unsat: 0.28s)
CPU Time     : 62.327s
Threads      : 4        (Winner: 2)

================================================================================
#### clingo warehouse.lp inst5.asp -t 4 -c t=13
================================================================================

clingo version 5.4.0
Reading from warehouse.lp ...
Solving...
Progression : [1;inf]
Answer: 1
occurs(object(robot,2),move(-1,0),1) occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,1),move(-1,0),3) occurs(object(robot,1),move(0,-1),4) occurs(object(robot,2),move(1,0),4) occurs(object(robot,2),move(1,0),5) occurs(object(robot,1),move(0,1),6) occurs(object(robot,1),move(0,1),8) occurs(object(robot,2),move(0,1),8) occurs(object(robot,2),move(-1,0),9) occurs(object(robot,1),move(1,0),9) occurs(object(robot,1),move(0,-1),12) occurs(object(robot,2),move(-1,0),12) occurs(object(robot,2),pickup,2) occurs(object(robot,2),putdown,3) occurs(object(robot,1),pickup,5) occurs(object(robot,2),pickup,10) occurs(object(robot,1),deliver(1,3,4),7) occurs(object(robot,2),deliver(1,1,1),13)
Optimization: 12
Answer: 2
occurs(object(robot,2),move(-1,0),1) occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(0,1),3) occurs(object(robot,1),move(0,1),4) occurs(object(robot,2),move(0,1),4) occurs(object(robot,2),move(0,-1),5) occurs(object(robot,1),move(-1,0),5) occurs(object(robot,1),move(0,-1),6) occurs(object(robot,2),move(0,-1),6) occurs(object(robot,1),move(0,1),8) occurs(object(robot,2),move(0,1),9) occurs(object(robot,1),move(1,0),10) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,3) occurs(object(robot,2),putdown,7) occurs(object(robot,2),pickup,8) occurs(object(robot,1),deliver(1,1,1),7) occurs(object(robot,2),deliver(1,3,4),10)
Optimization: 10
Progression : [ 2;10] (Error: 4)
Progression : [ 3;10] (Error: 2.33333)
Answer: 3
occurs(object(robot,2),move(-1,0),1) occurs(object(robot,1),move(-1,0),1) occurs(object(robot,1),move(-1,0),2) occurs(object(robot,2),move(0,1),3) occurs(object(robot,2),move(0,-1),5) occurs(object(robot,1),move(-1,0),6) occurs(object(robot,2),pickup,2) occurs(object(robot,1),pickup,4) occurs(object(robot,2),putdown,6) occurs(object(robot,2),deliver(1,3,4),4) occurs(object(robot,1),deliver(1,1,1),13)
Optimization: 7
Answer: 4
occurs(object(robot,2),move(-1,0),2) occurs(object(robot,1),move(-1,0),4) occurs(object(robot,2),move(0,1),5) occurs(object(robot,1),move(-1,0),5) occurs(object(robot,2),move(0,-1),9) occurs(object(robot,1),move(-1,0),9) occurs(object(robot,2),pickup,4) occurs(object(robot,1),pickup,6) occurs(object(robot,2),putdown,11) occurs(object(robot,2),deliver(1,3,4),6) occurs(object(robot,1),deliver(1,1,1),11)
Optimization: 6
Progression : [4;6] (Error: 0.5)
Progression : [5;6] (Error: 0.2)
OPTIMUM FOUND

Models       : 4
  Optimum    : yes
Optimization : 6
Calls        : 1
Time         : 13.275s (Solving: 0.90s 1st Model: 0.16s Unsat: 0.57s)
CPU Time     : 14.939s
Threads      : 4        (Winner: 1)

### Unsatisfiable Results
================================================================================
#### clingo warehouse.lp inst1.asp -t 4 -c t=12
================================================================================

clingo version 5.4.0
Reading from warehouse.lp ...
Solving...
Progression : [1;inf]
Progression : [2;inf]
UNSATISFIABLE

Models       : 0
Bounds       : [2;*]
Calls        : 1
Time         : 9.106s (Solving: 0.63s 1st Model: 0.00s Unsat: 0.63s)
CPU Time     : 10.785s
Threads      : 4        (Winner: 2)
