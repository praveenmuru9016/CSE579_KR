import numpy as np

with open('output.txt') as file:
    for line in file:
        if 'occurs' in line:
            actions = line.split()
            action_list = np.zeros((len(actions)), dtype=np.object)
            for i in range(action_list.shape[0]):
                action_list[i] = (int(actions[i][-5:].split(',')[1][:-1]), actions[i])
            
            print(np.sort(action_list))

